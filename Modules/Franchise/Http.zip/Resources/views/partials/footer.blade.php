<div class="dashboard-footer">
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-12"><div class="copy-right text-center">Copyright {{date('Y')}} All Rights Reserved by Ditechnical.</div></div>

        </div>
    </div>
</div>